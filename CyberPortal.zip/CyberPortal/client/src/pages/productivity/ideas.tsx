import React, { useState } from 'react';
import { useIdeasStore } from '@/store/dataStore';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Plus, 
  Search, 
  Lightbulb, 
  Edit, 
  Trash2, 
  Save, 
  Tag,
  Filter
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from '@/hooks/use-toast';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Idea } from '@/types';

export default function Ideas() {
  const { ideas, addIdea, updateIdea, deleteIdea } = useIdeasStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [currentIdea, setCurrentIdea] = useState<Idea | null>(null);
  const [newIdea, setNewIdea] = useState({
    title: '',
    description: '',
    category: '',
  });
  const { toast } = useToast();

  // Extract unique categories for the filter
  const categories = ['all', ...Array.from(new Set(ideas.map(idea => idea.category)))];

  const filteredIdeas = ideas
    .filter(idea => 
      (idea.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
      idea.description.toLowerCase().includes(searchTerm.toLowerCase())) &&
      (categoryFilter === 'all' || idea.category === categoryFilter)
    )
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const handleAddIdea = () => {
    if (!newIdea.title.trim() || !newIdea.description.trim() || !newIdea.category.trim()) {
      toast({
        title: "Campos obrigatórios",
        description: "Título, descrição e categoria são obrigatórios.",
        variant: "destructive",
      });
      return;
    }

    addIdea(newIdea.title, newIdea.description, newIdea.category);
    setNewIdea({
      title: '',
      description: '',
      category: '',
    });
    setIsAddDialogOpen(false);
    
    toast({
      title: "Ideia adicionada",
      description: "Sua ideia foi adicionada com sucesso.",
    });
  };

  const handleEditIdea = () => {
    if (!currentIdea || !currentIdea.title.trim() || !currentIdea.description.trim() || !currentIdea.category.trim()) {
      toast({
        title: "Campos obrigatórios",
        description: "Título, descrição e categoria são obrigatórios.",
        variant: "destructive",
      });
      return;
    }

    updateIdea(currentIdea.id, {
      title: currentIdea.title,
      description: currentIdea.description,
      category: currentIdea.category,
    });
    setCurrentIdea(null);
    setIsEditDialogOpen(false);
    
    toast({
      title: "Ideia atualizada",
      description: "Sua ideia foi atualizada com sucesso.",
    });
  };

  const handleDeleteIdea = () => {
    if (currentIdea) {
      deleteIdea(currentIdea.id);
      setCurrentIdea(null);
      setIsDeleteDialogOpen(false);
      
      toast({
        title: "Ideia excluída",
        description: "Sua ideia foi excluída com sucesso.",
      });
    }
  };

  return (
    <div className="p-6 animate-fadeIn">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
        <h1 className="text-2xl font-tech-mono text-terminal mb-4 md:mb-0">IDEIAS<span className="text-terminal/70">_</span></h1>
        
        <div className="flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2 w-full md:w-auto">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-terminal/60" size={18} />
            <Input
              placeholder="Buscar ideias..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-black border-terminal/30 focus:border-terminal text-terminal"
            />
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="bg-black border-terminal/30 text-terminal hover:border-terminal">
                <Filter size={18} className="mr-2" />
                Categoria
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="bg-black border-terminal/50">
              <DropdownMenuRadioGroup value={categoryFilter} onValueChange={setCategoryFilter}>
                {categories.map((category) => (
                  <DropdownMenuRadioItem key={category} value={category} className="text-terminal focus:text-terminal focus:bg-terminal/10">
                    {category === 'all' ? 'Todas as Categorias' : category}
                  </DropdownMenuRadioItem>
                ))}
              </DropdownMenuRadioGroup>
            </DropdownMenuContent>
          </DropdownMenu>
          
          <Button 
            onClick={() => setIsAddDialogOpen(true)} 
            className="bg-terminal/10 border border-terminal hover:bg-terminal/20 text-terminal"
          >
            <Plus size={18} className="mr-2" />
            Nova Ideia
          </Button>
        </div>
      </div>

      {filteredIdeas.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredIdeas.map((idea) => (
            <Card key={idea.id} className="bg-black border-terminal/30 hover:border-terminal transition-colors">
              <CardContent className="p-5">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <span className="bg-terminal/10 text-terminal text-xs px-2 py-1 rounded-sm flex items-center">
                      <Tag size={12} className="mr-1" />
                      {idea.category}
                    </span>
                  </div>
                  <div className="flex space-x-1">
                    <button
                      onClick={() => {
                        setCurrentIdea(idea);
                        setIsEditDialogOpen(true);
                      }}
                      className="p-1.5 text-terminal/60 hover:text-terminal rounded-full hover:bg-terminal/10"
                      aria-label="Editar ideia"
                    >
                      <Edit size={16} />
                    </button>
                    <button
                      onClick={() => {
                        setCurrentIdea(idea);
                        setIsDeleteDialogOpen(true);
                      }}
                      className="p-1.5 text-terminal/60 hover:text-red-400 rounded-full hover:bg-terminal/10"
                      aria-label="Excluir ideia"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
                
                <h3 className="font-bold text-lg mb-2 text-terminal">{idea.title}</h3>
                
                <p className="text-terminal/70 text-sm mb-3">{idea.description}</p>
                
                <div className="text-xs text-terminal/50">
                  Criado em {new Date(idea.createdAt).toLocaleDateString()}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center p-12 bg-black border border-terminal/30 rounded-sm">
          <Lightbulb size={48} className="text-terminal/40 mb-4" />
          <h3 className="text-xl font-semibold mb-2 text-terminal">Nenhuma ideia encontrada</h3>
          <p className="text-terminal/70 text-center mb-4">
            {searchTerm || categoryFilter !== 'all' 
              ? 'Nenhuma ideia corresponde aos seus filtros.' 
              : 'Você ainda não registrou nenhuma ideia.'}
          </p>
          <Button 
            onClick={() => setIsAddDialogOpen(true)} 
            className="bg-terminal/10 border border-terminal hover:bg-terminal/20 text-terminal"
          >
            <Plus size={18} className="mr-2" />
            Adicionar Ideia
          </Button>
        </div>
      )}

      {/* Add Idea Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="bg-black border-terminal/50 sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-terminal">Nova Ideia</DialogTitle>
            <DialogDescription className="text-terminal/70">
              Registre uma nova ideia para seu projeto.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-terminal">Título</label>
              <Input
                placeholder="Título da ideia"
                value={newIdea.title}
                onChange={(e) => setNewIdea({ ...newIdea, title: e.target.value })}
                className="bg-black border-terminal/30 text-terminal"
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-terminal">Descrição</label>
              <Textarea
                placeholder="Descreva sua ideia"
                value={newIdea.description}
                onChange={(e) => setNewIdea({ ...newIdea, description: e.target.value })}
                className="bg-black border-terminal/30 text-terminal min-h-[120px]"
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-terminal">Categoria</label>
              <Input
                placeholder="Ex: Produto, Feature, Melhoria"
                value={newIdea.category}
                onChange={(e) => setNewIdea({ ...newIdea, category: e.target.value })}
                className="bg-black border-terminal/30 text-terminal"
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              onClick={() => setIsAddDialogOpen(false)} 
              variant="outline"
              className="bg-black text-terminal border-terminal/50 hover:bg-terminal/10"
            >
              Cancelar
            </Button>
            <Button 
              onClick={handleAddIdea} 
              className="bg-terminal/10 border border-terminal hover:bg-terminal/20 text-terminal"
            >
              <Save size={16} className="mr-2" />
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Idea Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="bg-black border-terminal/50 sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-terminal">Editar Ideia</DialogTitle>
            <DialogDescription className="text-terminal/70">
              Atualize sua ideia.
            </DialogDescription>
          </DialogHeader>
          
          {currentIdea && (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-terminal">Título</label>
                <Input
                  placeholder="Título da ideia"
                  value={currentIdea.title}
                  onChange={(e) => setCurrentIdea({ ...currentIdea, title: e.target.value })}
                  className="bg-black border-terminal/30 text-terminal"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-terminal">Descrição</label>
                <Textarea
                  placeholder="Descreva sua ideia"
                  value={currentIdea.description}
                  onChange={(e) => setCurrentIdea({ ...currentIdea, description: e.target.value })}
                  className="bg-black border-terminal/30 text-terminal min-h-[120px]"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-terminal">Categoria</label>
                <Input
                  placeholder="Ex: Produto, Feature, Melhoria"
                  value={currentIdea.category}
                  onChange={(e) => setCurrentIdea({ ...currentIdea, category: e.target.value })}
                  className="bg-black border-terminal/30 text-terminal"
                />
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button 
              onClick={() => setIsEditDialogOpen(false)} 
              variant="outline"
              className="bg-black text-terminal border-terminal/50 hover:bg-terminal/10"
            >
              Cancelar
            </Button>
            <Button 
              onClick={handleEditIdea} 
              className="bg-terminal/10 border border-terminal hover:bg-terminal/20 text-terminal"
            >
              <Save size={16} className="mr-2" />
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Idea Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="bg-black border-terminal/50 sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-terminal">Excluir Ideia</DialogTitle>
            <DialogDescription className="text-terminal/70">
              Tem certeza que deseja excluir esta ideia? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          
          {currentIdea && (
            <div className="bg-terminal/5 border border-terminal/30 p-4 rounded-sm my-4">
              <h4 className="font-bold text-terminal">{currentIdea.title}</h4>
              <p className="text-sm text-terminal/70 mt-1">{currentIdea.description}</p>
            </div>
          )}
          
          <DialogFooter>
            <Button 
              onClick={() => setIsDeleteDialogOpen(false)} 
              variant="outline"
              className="bg-black text-terminal border-terminal/50 hover:bg-terminal/10"
            >
              Cancelar
            </Button>
            <Button 
              onClick={handleDeleteIdea} 
              className="bg-red-900/30 hover:bg-red-900/50 text-red-400 border border-red-500/50"
            >
              <Trash2 size={16} className="mr-2" />
              Excluir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}