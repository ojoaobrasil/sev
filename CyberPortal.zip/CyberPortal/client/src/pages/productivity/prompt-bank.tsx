import React, { useState } from 'react';
import { usePromptsStore } from '@/store/dataStore';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Plus, 
  Search, 
  MessageSquare, 
  Edit, 
  Trash2, 
  Save, 
  Copy,
  Tag,
  Filter
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from '@/hooks/use-toast';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Prompt } from '@/types';

export default function PromptBank() {
  const { prompts, addPrompt, updatePrompt, deletePrompt } = usePromptsStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [currentPrompt, setCurrentPrompt] = useState<Prompt | null>(null);
  const [newPrompt, setNewPrompt] = useState({
    title: '',
    content: '',
    category: '',
  });
  const { toast } = useToast();

  // Extract unique categories for the filter
  const categories = ['all', ...Array.from(new Set(prompts.map(prompt => prompt.category)))];

  const filteredPrompts = prompts
    .filter(prompt => 
      (prompt.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
      prompt.content.toLowerCase().includes(searchTerm.toLowerCase())) &&
      (categoryFilter === 'all' || prompt.category === categoryFilter)
    )
    .sort((a, b) => a.title.localeCompare(b.title));

  const handleAddPrompt = () => {
    if (!newPrompt.title.trim() || !newPrompt.content.trim() || !newPrompt.category.trim()) {
      toast({
        title: "Campos obrigatórios",
        description: "Título, conteúdo e categoria são obrigatórios.",
        variant: "destructive",
      });
      return;
    }

    addPrompt(newPrompt.title, newPrompt.content, newPrompt.category);
    setNewPrompt({
      title: '',
      content: '',
      category: '',
    });
    setIsAddDialogOpen(false);
    
    toast({
      title: "Prompt adicionado",
      description: "Seu prompt foi adicionado com sucesso.",
    });
  };

  const handleEditPrompt = () => {
    if (!currentPrompt || !currentPrompt.title.trim() || !currentPrompt.content.trim() || !currentPrompt.category.trim()) {
      toast({
        title: "Campos obrigatórios",
        description: "Título, conteúdo e categoria são obrigatórios.",
        variant: "destructive",
      });
      return;
    }

    updatePrompt(currentPrompt.id, {
      title: currentPrompt.title,
      content: currentPrompt.content,
      category: currentPrompt.category,
    });
    setCurrentPrompt(null);
    setIsEditDialogOpen(false);
    
    toast({
      title: "Prompt atualizado",
      description: "Seu prompt foi atualizado com sucesso.",
    });
  };

  const handleDeletePrompt = () => {
    if (currentPrompt) {
      deletePrompt(currentPrompt.id);
      setCurrentPrompt(null);
      setIsDeleteDialogOpen(false);
      
      toast({
        title: "Prompt excluído",
        description: "Seu prompt foi excluído com sucesso.",
      });
    }
  };

  const handleCopyPrompt = (content: string) => {
    navigator.clipboard.writeText(content);
    
    toast({
      title: "Prompt copiado",
      description: "O prompt foi copiado para a área de transferência.",
    });
  };

  return (
    <div className="p-6 animate-fadeIn">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
        <h1 className="text-2xl font-tech-mono text-terminal mb-4 md:mb-0">PROMPT BANK<span className="text-terminal/70">_</span></h1>
        
        <div className="flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2 w-full md:w-auto">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-terminal/60" size={18} />
            <Input
              placeholder="Buscar prompts..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-black border-terminal/30 focus:border-terminal text-terminal"
            />
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="bg-black border-terminal/30 text-terminal hover:border-terminal">
                <Filter size={18} className="mr-2" />
                Categoria
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="bg-black border-terminal/50">
              <DropdownMenuRadioGroup value={categoryFilter} onValueChange={setCategoryFilter}>
                {categories.map((category) => (
                  <DropdownMenuRadioItem key={category} value={category} className="text-terminal focus:text-terminal focus:bg-terminal/10">
                    {category === 'all' ? 'Todas as Categorias' : category}
                  </DropdownMenuRadioItem>
                ))}
              </DropdownMenuRadioGroup>
            </DropdownMenuContent>
          </DropdownMenu>
          
          <Button 
            onClick={() => setIsAddDialogOpen(true)} 
            className="bg-terminal/10 border border-terminal hover:bg-terminal/20 text-terminal"
          >
            <Plus size={18} className="mr-2" />
            Novo Prompt
          </Button>
        </div>
      </div>

      {filteredPrompts.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredPrompts.map((prompt) => (
            <Card key={prompt.id} className="bg-black border-terminal/30 hover:border-terminal transition-colors">
              <CardContent className="p-5">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <div className="flex items-center">
                      <span className="bg-terminal/10 text-terminal text-xs px-2 py-1 rounded-sm flex items-center mr-2">
                        <Tag size={12} className="mr-1" />
                        {prompt.category}
                      </span>
                    </div>
                  </div>
                  <div className="flex space-x-1">
                    <button
                      onClick={() => {
                        setCurrentPrompt(prompt);
                        setIsEditDialogOpen(true);
                      }}
                      className="p-1.5 text-terminal/60 hover:text-terminal rounded-full hover:bg-terminal/10"
                      aria-label="Editar prompt"
                    >
                      <Edit size={16} />
                    </button>
                    <button
                      onClick={() => {
                        setCurrentPrompt(prompt);
                        setIsDeleteDialogOpen(true);
                      }}
                      className="p-1.5 text-terminal/60 hover:text-red-400 rounded-full hover:bg-terminal/10"
                      aria-label="Excluir prompt"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
                
                <h3 className="font-bold text-lg mb-2 line-clamp-1 text-terminal">{prompt.title}</h3>
                
                <div className="text-terminal/70 text-sm mb-3 line-clamp-3 bg-terminal/5 p-2 rounded font-mono">
                  {prompt.content}
                </div>
                
                <Button 
                  onClick={() => handleCopyPrompt(prompt.content)} 
                  className="w-full bg-terminal/10 border border-terminal hover:bg-terminal/20 text-terminal"
                >
                  <Copy size={16} className="mr-2" />
                  Copiar Prompt
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center p-12 bg-black border border-terminal/30 rounded-sm">
          <MessageSquare size={48} className="text-terminal/40 mb-4" />
          <h3 className="text-xl font-semibold mb-2 text-terminal">Nenhum prompt encontrado</h3>
          <p className="text-terminal/70 text-center mb-4">
            {searchTerm || categoryFilter !== 'all' 
              ? 'Nenhum prompt corresponde aos seus filtros.' 
              : 'Você ainda não tem nenhum prompt salvo.'}
          </p>
          <Button 
            onClick={() => setIsAddDialogOpen(true)} 
            className="bg-terminal/10 border border-terminal hover:bg-terminal/20 text-terminal"
          >
            <Plus size={18} className="mr-2" />
            Adicionar Prompt
          </Button>
        </div>
      )}

      {/* Add Prompt Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="bg-black border-terminal/50 sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-terminal">Novo Prompt</DialogTitle>
            <DialogDescription className="text-terminal/70">
              Adicione um novo prompt para sua coleção.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-terminal">Título</label>
              <Input
                placeholder="Título do prompt"
                value={newPrompt.title}
                onChange={(e) => setNewPrompt({ ...newPrompt, title: e.target.value })}
                className="bg-black border-terminal/30 text-terminal"
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-terminal">Conteúdo</label>
              <Textarea
                placeholder="Conteúdo do prompt"
                value={newPrompt.content}
                onChange={(e) => setNewPrompt({ ...newPrompt, content: e.target.value })}
                className="bg-black border-terminal/30 text-terminal min-h-[150px] font-mono"
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-terminal">Categoria</label>
              <Input
                placeholder="Ex: Escrita, SEO, Análise"
                value={newPrompt.category}
                onChange={(e) => setNewPrompt({ ...newPrompt, category: e.target.value })}
                className="bg-black border-terminal/30 text-terminal"
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              onClick={() => setIsAddDialogOpen(false)} 
              variant="outline"
              className="bg-black text-terminal border-terminal/50 hover:bg-terminal/10"
            >
              Cancelar
            </Button>
            <Button 
              onClick={handleAddPrompt} 
              className="bg-terminal/10 border border-terminal hover:bg-terminal/20 text-terminal"
            >
              <Save size={16} className="mr-2" />
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Prompt Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="bg-black border-terminal/50 sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-terminal">Editar Prompt</DialogTitle>
            <DialogDescription className="text-terminal/70">
              Atualize seu prompt.
            </DialogDescription>
          </DialogHeader>
          
          {currentPrompt && (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-terminal">Título</label>
                <Input
                  placeholder="Título do prompt"
                  value={currentPrompt.title}
                  onChange={(e) => setCurrentPrompt({ ...currentPrompt, title: e.target.value })}
                  className="bg-black border-terminal/30 text-terminal"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-terminal">Conteúdo</label>
                <Textarea
                  placeholder="Conteúdo do prompt"
                  value={currentPrompt.content}
                  onChange={(e) => setCurrentPrompt({ ...currentPrompt, content: e.target.value })}
                  className="bg-black border-terminal/30 text-terminal min-h-[150px] font-mono"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-terminal">Categoria</label>
                <Input
                  placeholder="Ex: Escrita, SEO, Análise"
                  value={currentPrompt.category}
                  onChange={(e) => setCurrentPrompt({ ...currentPrompt, category: e.target.value })}
                  className="bg-black border-terminal/30 text-terminal"
                />
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button 
              onClick={() => setIsEditDialogOpen(false)} 
              variant="outline"
              className="bg-black text-terminal border-terminal/50 hover:bg-terminal/10"
            >
              Cancelar
            </Button>
            <Button 
              onClick={handleEditPrompt} 
              className="bg-terminal/10 border border-terminal hover:bg-terminal/20 text-terminal"
            >
              <Save size={16} className="mr-2" />
              Atualizar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Prompt Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="bg-black border-terminal/50 sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-terminal">Excluir Prompt</DialogTitle>
            <DialogDescription className="text-terminal/70">
              Tem certeza que deseja excluir este prompt? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          
          {currentPrompt && (
            <div className="bg-terminal/5 border border-terminal/30 p-4 rounded-sm my-4">
              <h4 className="font-bold text-terminal">{currentPrompt.title}</h4>
              <p className="text-sm text-terminal/70 mt-1 font-mono line-clamp-3">{currentPrompt.content}</p>
            </div>
          )}
          
          <DialogFooter>
            <Button 
              onClick={() => setIsDeleteDialogOpen(false)} 
              variant="outline"
              className="bg-black text-terminal border-terminal/50 hover:bg-terminal/10"
            >
              Cancelar
            </Button>
            <Button 
              onClick={handleDeletePrompt} 
              className="bg-red-900/30 hover:bg-red-900/50 text-red-400 border border-red-500/50"
            >
              <Trash2 size={16} className="mr-2" />
              Excluir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}