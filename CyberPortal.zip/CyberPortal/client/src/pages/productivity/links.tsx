import React, { useState } from 'react';
import { useLinksStore } from '@/store/dataStore';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Plus, 
  Search, 
  Link as LinkIcon, 
  Edit, 
  Trash2, 
  Save, 
  ExternalLink,
  Tag,
  Filter
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from '@/hooks/use-toast';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { UsefulLink } from '@/types';

export default function Links() {
  const { links, addLink, updateLink, deleteLink } = useLinksStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [currentLink, setCurrentLink] = useState<UsefulLink | null>(null);
  const [newLink, setNewLink] = useState({
    title: '',
    url: '',
    description: '',
    category: '',
  });
  const { toast } = useToast();

  // Extract unique categories for the filter
  const categories = ['all', ...Array.from(new Set(links.map(link => link.category)))];

  const filteredLinks = links
    .filter(link => 
      (link.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
      link.description.toLowerCase().includes(searchTerm.toLowerCase())) &&
      (categoryFilter === 'all' || link.category === categoryFilter)
    )
    .sort((a, b) => a.title.localeCompare(b.title));

  const handleAddLink = () => {
    if (!newLink.title.trim() || !newLink.url.trim() || !newLink.category.trim()) {
      toast({
        title: "Campos obrigatórios",
        description: "Título, URL e categoria são obrigatórios.",
        variant: "destructive",
      });
      return;
    }

    // Validate URL
    try {
      new URL(newLink.url);
    } catch (e) {
      toast({
        title: "URL inválida",
        description: "Por favor, insira uma URL válida começando com http:// ou https://.",
        variant: "destructive",
      });
      return;
    }

    addLink(newLink.title, newLink.url, newLink.description, newLink.category);
    setNewLink({
      title: '',
      url: '',
      description: '',
      category: '',
    });
    setIsAddDialogOpen(false);
    
    toast({
      title: "Link adicionado",
      description: "Seu link foi adicionado com sucesso.",
    });
  };

  const handleEditLink = () => {
    if (!currentLink || !currentLink.title.trim() || !currentLink.url.trim() || !currentLink.category.trim()) {
      toast({
        title: "Campos obrigatórios",
        description: "Título, URL e categoria são obrigatórios.",
        variant: "destructive",
      });
      return;
    }

    // Validate URL
    try {
      new URL(currentLink.url);
    } catch (e) {
      toast({
        title: "URL inválida",
        description: "Por favor, insira uma URL válida começando com http:// ou https://.",
        variant: "destructive",
      });
      return;
    }

    updateLink(currentLink.id, {
      title: currentLink.title,
      url: currentLink.url,
      description: currentLink.description,
      category: currentLink.category,
    });
    setCurrentLink(null);
    setIsEditDialogOpen(false);
    
    toast({
      title: "Link atualizado",
      description: "Seu link foi atualizado com sucesso.",
    });
  };

  const handleDeleteLink = () => {
    if (currentLink) {
      deleteLink(currentLink.id);
      setCurrentLink(null);
      setIsDeleteDialogOpen(false);
      
      toast({
        title: "Link excluído",
        description: "Seu link foi excluído com sucesso.",
      });
    }
  };

  const openExternalLink = (url: string) => {
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="p-6 animate-fadeIn">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
        <h1 className="text-2xl font-tech-mono text-terminal mb-4 md:mb-0">LINKS<span className="text-terminal/70">_</span></h1>
        
        <div className="flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2 w-full md:w-auto">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-terminal/60" size={18} />
            <Input
              placeholder="Buscar links..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-black border-terminal/30 focus:border-terminal text-terminal"
            />
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="bg-black border-terminal/30 text-terminal hover:border-terminal">
                <Filter size={18} className="mr-2" />
                Categoria
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="bg-black border-terminal/50">
              <DropdownMenuRadioGroup value={categoryFilter} onValueChange={setCategoryFilter}>
                {categories.map((category) => (
                  <DropdownMenuRadioItem key={category} value={category} className="text-terminal focus:text-terminal focus:bg-terminal/10">
                    {category === 'all' ? 'Todas as Categorias' : category}
                  </DropdownMenuRadioItem>
                ))}
              </DropdownMenuRadioGroup>
            </DropdownMenuContent>
          </DropdownMenu>
          
          <Button 
            onClick={() => setIsAddDialogOpen(true)} 
            className="bg-terminal/10 border border-terminal hover:bg-terminal/20 text-terminal"
          >
            <Plus size={18} className="mr-2" />
            Novo Link
          </Button>
        </div>
      </div>

      {filteredLinks.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredLinks.map((link) => (
            <Card key={link.id} className="bg-black border-terminal/30 hover:border-terminal transition-colors">
              <CardContent className="p-5">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <div className="flex items-center">
                      <span className="bg-terminal/10 text-terminal text-xs px-2 py-1 rounded-sm flex items-center mr-2">
                        <Tag size={12} className="mr-1" />
                        {link.category}
                      </span>
                    </div>
                  </div>
                  <div className="flex space-x-1">
                    <button
                      onClick={() => {
                        setCurrentLink(link);
                        setIsEditDialogOpen(true);
                      }}
                      className="p-1.5 text-terminal/60 hover:text-terminal rounded-full hover:bg-terminal/10"
                      aria-label="Editar link"
                    >
                      <Edit size={16} />
                    </button>
                    <button
                      onClick={() => {
                        setCurrentLink(link);
                        setIsDeleteDialogOpen(true);
                      }}
                      className="p-1.5 text-terminal/60 hover:text-red-400 rounded-full hover:bg-terminal/10"
                      aria-label="Excluir link"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
                
                <h3 className="font-bold text-lg mb-2 line-clamp-1 text-terminal">{link.title}</h3>
                
                <p className="text-terminal/70 text-sm mb-3 line-clamp-2">{link.description}</p>
                
                <Button 
                  onClick={() => openExternalLink(link.url)} 
                  className="w-full bg-terminal/10 border border-terminal hover:bg-terminal/20 text-terminal"
                >
                  <ExternalLink size={16} className="mr-2" />
                  Abrir Link
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center p-12 bg-black border border-terminal/30 rounded-sm">
          <LinkIcon size={48} className="text-terminal/40 mb-4" />
          <h3 className="text-xl font-semibold mb-2 text-terminal">Nenhum link encontrado</h3>
          <p className="text-terminal/70 text-center mb-4">
            {searchTerm || categoryFilter !== 'all' 
              ? 'Nenhum link corresponde aos seus filtros.' 
              : 'Você ainda não tem nenhum link útil.'}
          </p>
          <Button 
            onClick={() => setIsAddDialogOpen(true)} 
            className="bg-terminal/10 border border-terminal hover:bg-terminal/20 text-terminal"
          >
            <Plus size={18} className="mr-2" />
            Adicionar Link
          </Button>
        </div>
      )}

      {/* Add Link Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="bg-black border-terminal/50 sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-terminal">Novo Link</DialogTitle>
            <DialogDescription className="text-terminal/70">
              Adicione um novo link útil.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-terminal">Título</label>
              <Input
                placeholder="Título do link"
                value={newLink.title}
                onChange={(e) => setNewLink({ ...newLink, title: e.target.value })}
                className="bg-black border-terminal/30 text-terminal"
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-terminal">URL</label>
              <Input
                placeholder="https://exemplo.com"
                value={newLink.url}
                onChange={(e) => setNewLink({ ...newLink, url: e.target.value })}
                className="bg-black border-terminal/30 text-terminal"
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-terminal">Descrição</label>
              <Textarea
                placeholder="Descrição do link"
                value={newLink.description}
                onChange={(e) => setNewLink({ ...newLink, description: e.target.value })}
                className="bg-black border-terminal/30 text-terminal min-h-[80px]"
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-terminal">Categoria</label>
              <Input
                placeholder="Ex: Documentação, Ferramentas, Referência"
                value={newLink.category}
                onChange={(e) => setNewLink({ ...newLink, category: e.target.value })}
                className="bg-black border-terminal/30 text-terminal"
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              onClick={() => setIsAddDialogOpen(false)} 
              variant="outline"
              className="bg-black text-terminal border-terminal/50 hover:bg-terminal/10"
            >
              Cancelar
            </Button>
            <Button 
              onClick={handleAddLink} 
              className="bg-terminal/10 border border-terminal hover:bg-terminal/20 text-terminal"
            >
              <Save size={16} className="mr-2" />
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Link Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="bg-black border-terminal/50 sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-terminal">Editar Link</DialogTitle>
            <DialogDescription className="text-terminal/70">
              Atualize seu link útil.
            </DialogDescription>
          </DialogHeader>
          
          {currentLink && (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-terminal">Título</label>
                <Input
                  placeholder="Título do link"
                  value={currentLink.title}
                  onChange={(e) => setCurrentLink({ ...currentLink, title: e.target.value })}
                  className="bg-black border-terminal/30 text-terminal"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-terminal">URL</label>
                <Input
                  placeholder="https://exemplo.com"
                  value={currentLink.url}
                  onChange={(e) => setCurrentLink({ ...currentLink, url: e.target.value })}
                  className="bg-black border-terminal/30 text-terminal"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-terminal">Descrição</label>
                <Textarea
                  placeholder="Descrição do link"
                  value={currentLink.description}
                  onChange={(e) => setCurrentLink({ ...currentLink, description: e.target.value })}
                  className="bg-black border-terminal/30 text-terminal min-h-[80px]"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-terminal">Categoria</label>
                <Input
                  placeholder="Ex: Documentação, Ferramentas, Referência"
                  value={currentLink.category}
                  onChange={(e) => setCurrentLink({ ...currentLink, category: e.target.value })}
                  className="bg-black border-terminal/30 text-terminal"
                />
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button 
              onClick={() => setIsEditDialogOpen(false)} 
              variant="outline"
              className="bg-black text-terminal border-terminal/50 hover:bg-terminal/10"
            >
              Cancelar
            </Button>
            <Button 
              onClick={handleEditLink} 
              className="bg-terminal/10 border border-terminal hover:bg-terminal/20 text-terminal"
            >
              <Save size={16} className="mr-2" />
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Link Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="bg-black border-terminal/50 sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-terminal">Excluir Link</DialogTitle>
            <DialogDescription className="text-terminal/70">
              Tem certeza que deseja excluir este link? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          
          {currentLink && (
            <div className="bg-terminal/5 border border-terminal/30 p-4 rounded-sm my-4">
              <h4 className="font-bold text-terminal">{currentLink.title}</h4>
              <p className="text-sm text-terminal/70 mt-1">{currentLink.url}</p>
              <p className="text-sm text-terminal/70 mt-1">{currentLink.description}</p>
            </div>
          )}
          
          <DialogFooter>
            <Button 
              onClick={() => setIsDeleteDialogOpen(false)} 
              variant="outline"
              className="bg-black text-terminal border-terminal/50 hover:bg-terminal/10"
            >
              Cancelar
            </Button>
            <Button 
              onClick={handleDeleteLink} 
              className="bg-red-900/30 hover:bg-red-900/50 text-red-400 border border-red-500/50"
            >
              <Trash2 size={16} className="mr-2" />
              Excluir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}