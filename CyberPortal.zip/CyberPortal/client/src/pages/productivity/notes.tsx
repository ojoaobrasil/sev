import React, { useState } from 'react';
import { useNotesStore } from '@/store/dataStore';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Plus, 
  Search, 
  FileText, 
  Edit, 
  Trash2, 
  Save, 
  Calendar
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from '@/hooks/use-toast';
import { Note } from '@/types';

export default function Notes() {
  const { notes, addNote, updateNote, deleteNote } = useNotesStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [currentNote, setCurrentNote] = useState<Note | null>(null);
  const [newNote, setNewNote] = useState({
    title: '',
    content: '',
  });
  const { toast } = useToast();

  const filteredNotes = notes
    .filter(note => 
      note.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
      note.content.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());

  const handleAddNote = () => {
    if (!newNote.title.trim() || !newNote.content.trim()) {
      toast({
        title: "Campos obrigatórios",
        description: "Título e conteúdo são obrigatórios.",
        variant: "destructive",
      });
      return;
    }

    addNote(newNote.title, newNote.content);
    setNewNote({
      title: '',
      content: '',
    });
    setIsAddDialogOpen(false);
    
    toast({
      title: "Anotação adicionada",
      description: "Sua anotação foi adicionada com sucesso.",
    });
  };

  const handleEditNote = () => {
    if (!currentNote || !currentNote.title.trim() || !currentNote.content.trim()) {
      toast({
        title: "Campos obrigatórios",
        description: "Título e conteúdo são obrigatórios.",
        variant: "destructive",
      });
      return;
    }

    updateNote(currentNote.id, {
      title: currentNote.title,
      content: currentNote.content,
      updatedAt: new Date(),
    });
    setCurrentNote(null);
    setIsEditDialogOpen(false);
    
    toast({
      title: "Anotação atualizada",
      description: "Sua anotação foi atualizada com sucesso.",
    });
  };

  const handleDeleteNote = () => {
    if (currentNote) {
      deleteNote(currentNote.id);
      setCurrentNote(null);
      setIsDeleteDialogOpen(false);
      
      toast({
        title: "Anotação excluída",
        description: "Sua anotação foi excluída com sucesso.",
      });
    }
  };

  return (
    <div className="p-6 animate-fadeIn">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
        <h1 className="text-2xl font-tech-mono text-terminal mb-4 md:mb-0">ANOTAÇÕES<span className="text-terminal/70">_</span></h1>
        
        <div className="flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2 w-full md:w-auto">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-terminal/60" size={18} />
            <Input
              placeholder="Buscar anotações..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-black border-terminal/30 focus:border-terminal text-terminal"
            />
          </div>
          
          <Button 
            onClick={() => setIsAddDialogOpen(true)} 
            className="bg-terminal/10 border border-terminal hover:bg-terminal/20 text-terminal"
          >
            <Plus size={18} className="mr-2" />
            Nova Anotação
          </Button>
        </div>
      </div>

      {filteredNotes.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredNotes.map((note) => (
            <Card key={note.id} className="bg-black border-terminal/30 hover:border-terminal transition-colors">
              <CardContent className="p-5">
                <div className="flex justify-between items-start mb-3">
                  <h3 className="font-bold text-lg mb-2 text-terminal line-clamp-1">{note.title}</h3>
                  <div className="flex space-x-1">
                    <button
                      onClick={() => {
                        setCurrentNote(note);
                        setIsEditDialogOpen(true);
                      }}
                      className="p-1.5 text-terminal/60 hover:text-terminal rounded-full hover:bg-terminal/10"
                      aria-label="Editar anotação"
                    >
                      <Edit size={16} />
                    </button>
                    <button
                      onClick={() => {
                        setCurrentNote(note);
                        setIsDeleteDialogOpen(true);
                      }}
                      className="p-1.5 text-terminal/60 hover:text-red-400 rounded-full hover:bg-terminal/10"
                      aria-label="Excluir anotação"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
                
                <div className="text-terminal/70 text-sm mb-3 line-clamp-4">
                  {note.content}
                </div>
                
                <div className="text-xs text-terminal/50 flex items-center">
                  <Calendar size={12} className="mr-1" />
                  Atualizado em {new Date(note.updatedAt).toLocaleDateString()}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center p-12 bg-black border border-terminal/30 rounded-sm">
          <FileText size={48} className="text-terminal/40 mb-4" />
          <h3 className="text-xl font-semibold mb-2 text-terminal">Nenhuma anotação encontrada</h3>
          <p className="text-terminal/70 text-center mb-4">
            {searchTerm 
              ? 'Nenhuma anotação corresponde à sua busca.' 
              : 'Você ainda não tem nenhuma anotação.'}
          </p>
          <Button 
            onClick={() => setIsAddDialogOpen(true)} 
            className="bg-terminal/10 border border-terminal hover:bg-terminal/20 text-terminal"
          >
            <Plus size={18} className="mr-2" />
            Criar Anotação
          </Button>
        </div>
      )}

      {/* Add Note Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="bg-black border-terminal/50 sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-terminal">Nova Anotação</DialogTitle>
            <DialogDescription className="text-terminal/70">
              Crie uma nova anotação para seu projeto.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-terminal">Título</label>
              <Input
                placeholder="Título da anotação"
                value={newNote.title}
                onChange={(e) => setNewNote({ ...newNote, title: e.target.value })}
                className="bg-black border-terminal/30 text-terminal"
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-terminal">Conteúdo</label>
              <Textarea
                placeholder="Conteúdo da anotação"
                value={newNote.content}
                onChange={(e) => setNewNote({ ...newNote, content: e.target.value })}
                className="bg-black border-terminal/30 text-terminal min-h-[150px]"
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              onClick={() => setIsAddDialogOpen(false)} 
              variant="outline"
              className="bg-black text-terminal border-terminal/50 hover:bg-terminal/10"
            >
              Cancelar
            </Button>
            <Button 
              onClick={handleAddNote} 
              className="bg-terminal/10 border border-terminal hover:bg-terminal/20 text-terminal"
            >
              <Save size={16} className="mr-2" />
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Note Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="bg-black border-terminal/50 sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-terminal">Editar Anotação</DialogTitle>
            <DialogDescription className="text-terminal/70">
              Atualize sua anotação.
            </DialogDescription>
          </DialogHeader>
          
          {currentNote && (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-terminal">Título</label>
                <Input
                  placeholder="Título da anotação"
                  value={currentNote.title}
                  onChange={(e) => setCurrentNote({ ...currentNote, title: e.target.value })}
                  className="bg-black border-terminal/30 text-terminal"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-terminal">Conteúdo</label>
                <Textarea
                  placeholder="Conteúdo da anotação"
                  value={currentNote.content}
                  onChange={(e) => setCurrentNote({ ...currentNote, content: e.target.value })}
                  className="bg-black border-terminal/30 text-terminal min-h-[150px]"
                />
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button 
              onClick={() => setIsEditDialogOpen(false)} 
              variant="outline"
              className="bg-black text-terminal border-terminal/50 hover:bg-terminal/10"
            >
              Cancelar
            </Button>
            <Button 
              onClick={handleEditNote} 
              className="bg-terminal/10 border border-terminal hover:bg-terminal/20 text-terminal"
            >
              <Save size={16} className="mr-2" />
              Atualizar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Note Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="bg-black border-terminal/50 sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-terminal">Excluir Anotação</DialogTitle>
            <DialogDescription className="text-terminal/70">
              Tem certeza que deseja excluir esta anotação? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          
          {currentNote && (
            <div className="bg-terminal/5 border border-terminal/30 p-4 rounded-sm my-4">
              <h4 className="font-bold text-terminal">{currentNote.title}</h4>
              <p className="text-sm text-terminal/70 mt-1 line-clamp-3">{currentNote.content}</p>
            </div>
          )}
          
          <DialogFooter>
            <Button 
              onClick={() => setIsDeleteDialogOpen(false)} 
              variant="outline"
              className="bg-black text-terminal border-terminal/50 hover:bg-terminal/10"
            >
              Cancelar
            </Button>
            <Button 
              onClick={handleDeleteNote} 
              className="bg-red-900/30 hover:bg-red-900/50 text-red-400 border border-red-500/50"
            >
              <Trash2 size={16} className="mr-2" />
              Excluir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}