import React, { useState, useEffect } from 'react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { useSettingsStore } from '@/store/dataStore';
import { useTheme } from '@/hooks/use-theme';
import { useToast } from '@/hooks/use-toast';
import { 
  Settings as SettingsIcon, 
  Moon, 
  Sun, 
  Bot, 
  Webhook,
  Key,
  Save,
  Bot as BotIcon
} from 'lucide-react';

export default function Settings() {
  const { settings, updateSettings } = useSettingsStore();
  const { theme, setTheme } = useTheme();
  const { toast } = useToast();

  const [formState, setFormState] = useState({
    openaiApiKey: settings.openaiApiKey || '',
    webhookUrl: settings.webhookUrl || 'https://gen.simplebot.online/webhook/b8f10f59-0108-43f1-afce-e782eda6ebe0',
    promptMakerAssistantId: settings.promptMakerAssistantId || '',
    chatBubbleAssistantId: settings.chatBubbleAssistantId || '',
    theme: settings.theme || 'dark',
  });

  const [showApiKey, setShowApiKey] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Sincronizar tema
  useEffect(() => {
    setFormState(prev => ({
      ...prev,
      theme: theme as 'dark' | 'light'
    }));
  }, [theme]);

  const handleChange = (field: string, value: any) => {
    setFormState({
      ...formState,
      [field]: value,
    });
  };

  const handleToggleTheme = () => {
    const newTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
  };

  const saveSettings = async () => {
    setIsLoading(true);
    try {
      updateSettings({
        openaiApiKey: formState.openaiApiKey,
        webhookUrl: formState.webhookUrl,
        promptMakerAssistantId: formState.promptMakerAssistantId,
        chatBubbleAssistantId: formState.chatBubbleAssistantId,
        theme: formState.theme as 'dark' | 'light',
      });

      // Salvar ID do assistente da bolha de chat no localStorage
      if (formState.chatBubbleAssistantId) {
        localStorage.setItem('chat_bubble_assistant_id', formState.chatBubbleAssistantId);
      }

      toast({
        title: "Configurações salvas",
        description: "Suas configurações foram atualizadas com sucesso."
      });
    } catch (error) {
      toast({
        title: "Erro ao salvar",
        description: "Ocorreu um erro ao salvar as configurações.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container py-6 max-w-4xl">
      <div className="flex flex-col space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Configurações</h1>
            <p className="text-muted-foreground">
              Gerencie suas preferências e configurações do sistema.
            </p>
          </div>
        </div>

        <Tabs defaultValue="general" className="w-full space-y-6">
          <TabsList className="mb-4">
            <TabsTrigger value="general">
              <SettingsIcon className="h-4 w-4 mr-2" />
              Geral
            </TabsTrigger>
            <TabsTrigger value="api">
              <Key className="h-4 w-4 mr-2" />
              APIs e Integrações
            </TabsTrigger>
            <TabsTrigger value="assistants">
              <BotIcon className="h-4 w-4 mr-2" />
              Assistentes
            </TabsTrigger>
          </TabsList>

          {/* Aba Geral */}
          <TabsContent value="general" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Aparência</CardTitle>
                <CardDescription>
                  Personalize a aparência da interface.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Tema Escuro</Label>
                    <div className="text-sm text-muted-foreground">
                      Alternar entre tema claro e escuro.
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Sun className="h-4 w-4" />
                    <Switch 
                      checked={theme === 'dark'} 
                      onCheckedChange={handleToggleTheme}
                    />
                    <Moon className="h-4 w-4" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Aba API e Integrações */}
          <TabsContent value="api" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Key className="mr-2 h-5 w-5 text-terminal" />
                  OpenAI API
                </CardTitle>
                <CardDescription>
                  Configure sua chave da API para utilizar os recursos de IA.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="openaiApiKey">Chave da API OpenAI</Label>
                  <div className="flex">
                    <Input
                      id="openaiApiKey"
                      type={showApiKey ? "text" : "password"}
                      value={formState.openaiApiKey || ''}
                      onChange={(e) => handleChange('openaiApiKey', e.target.value)}
                      placeholder="sk-..."
                      className="flex-1"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      className="ml-2"
                      onClick={() => setShowApiKey(!showApiKey)}
                    >
                      {showApiKey ? "Esconder" : "Mostrar"}
                    </Button>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Essa chave é usada para todos os recursos de IA, exceto o Chat CEO.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Webhook className="mr-2 h-5 w-5 text-terminal" />
                  Webhook para Chat CEO
                </CardTitle>
                <CardDescription>
                  Configure a URL do webhook para o Chat CEO.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="webhookUrl">URL do Webhook</Label>
                  <Input
                    id="webhookUrl"
                    value={formState.webhookUrl || ''}
                    onChange={(e) => handleChange('webhookUrl', e.target.value)}
                    placeholder="https://gen.simplebot.online/webhook/..."
                  />
                  <p className="text-sm text-muted-foreground">
                    URL do webhook para o Chat CEO. Necessário para o funcionamento do chat.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Aba Assistentes */}
          <TabsContent value="assistants" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Bot className="mr-2 h-5 w-5 text-terminal" />
                  Configuração de Assistentes
                </CardTitle>
                <CardDescription>
                  Configure os IDs dos diferentes assistentes da plataforma.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="promptMakerAssistantId">ID do Assistente para Prompt Maker</Label>
                  <Input
                    id="promptMakerAssistantId"
                    value={formState.promptMakerAssistantId || ''}
                    onChange={(e) => handleChange('promptMakerAssistantId', e.target.value)}
                    placeholder="asst_..."
                  />
                  <p className="text-sm text-muted-foreground">
                    ID do assistente usado pelo módulo Prompt Maker.
                  </p>
                </div>

                <div className="space-y-2 mt-4">
                  <Label htmlFor="chatBubbleAssistantId">ID do Assistente para Chat Flutuante</Label>
                  <Input
                    id="chatBubbleAssistantId"
                    value={formState.chatBubbleAssistantId || ''}
                    onChange={(e) => handleChange('chatBubbleAssistantId', e.target.value)}
                    placeholder="asst_..."
                  />
                  <p className="text-sm text-muted-foreground">
                    ID do assistente usado pelo chat flutuante que aparece em todas as páginas.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex justify-end">
          <Button 
            onClick={saveSettings} 
            className="bg-terminal hover:bg-terminal/90 text-white"
            disabled={isLoading}
          >
            <Save className="mr-2 h-4 w-4" />
            {isLoading ? "Salvando..." : "Salvar Configurações"}
          </Button>
        </div>
      </div>
    </div>
  );
}