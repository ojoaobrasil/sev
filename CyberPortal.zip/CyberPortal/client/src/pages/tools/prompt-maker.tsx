import React, { useState, useEffect } from 'react';
import { useSettingsStore } from '@/store/dataStore';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import {
  Wand2,
  Copy,
  Save,
  RefreshCw,
  Sparkles,
  MessageSquare
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { usePromptsStore } from '@/store/dataStore';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from '@/components/ui/input';

const templates = [
  {
    id: 'writing',
    title: 'Escrita Criativa',
    icon: <FileText size={16} />,
    content: 'Você é um escritor criativo talentoso. Por favor, escreva {formato} sobre {assunto} com o seguinte tom: {tom}. Use {estilo} como referência e inclua {elementos}.'
  },
  {
    id: 'seo',
    title: 'Conteúdo SEO',
    icon: <Zap size={16} />,
    content: 'Como especialista em SEO, crie um conteúdo otimizado para o termo {palavra-chave} que inclua {h1} como título principal, {h2s} como subtítulos, e tenha aproximadamente {comprimento} palavras. O público-alvo é {público}.'
  },
  {
    id: 'summary',
    title: 'Resumo de Texto',
    icon: <BookText size={16} />,
    content: 'Resuma o seguinte texto em {comprimento} parágrafos, mantendo os pontos-chave e focando nos aspectos mais importantes:\n\n{texto}'
  },
  {
    id: 'custom',
    title: 'Personalizado',
    icon: <LayoutTemplate size={16} />,
    content: 'Escreva seu prompt personalizado aqui...'
  }
];

export default function PromptMaker() {
  const { settings } = useSettingsStore();
  const { prompts, addPrompt } = usePromptsStore();
  const [selectedTemplate, setSelectedTemplate] = useState(templates[0]);
  const [prompt, setPrompt] = useState('');
  const [result, setResult] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSaveDialogOpen, setIsSaveDialogOpen] = useState(false);
  const [savedPrompt, setSavedPrompt] = useState({
    title: '',
    category: '',
  });
  const { toast } = useToast();

  const generatePrompt = async () => {
    if (!prompt.trim()) {
      toast({
        title: "Campo vazio",
        description: "Por favor, digite um prompt básico para desenvolver.",
        variant: "destructive",
      });
      return;
    }

    if (!settings.openaiApiKey || !settings.promptMakerAssistantId) {
      toast({
        title: "Configuração necessária",
        description: "Configure a chave da OpenAI e o ID do assistente nas configurações.",
        variant: "destructive",
      });
      return;
    }

    setIsGenerating(true);
    setResult('Aguarde, gerando prompt aprimorado...');

    try {
      const threadRes = await fetch("https://api.openai.com/v1/threads", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${settings.openaiApiKey}`,
          "Content-Type": "application/json",
          "OpenAI-Beta": "assistants=v2"
        }
      });

      if (!threadRes.ok) {
        const error = await threadRes.json();
        throw new Error(error.error?.message || 'Erro ao criar thread');
      }

      const thread = await threadRes.json();

      const messageRes = await fetch(`https://api.openai.com/v1/threads/${thread.id}/messages`, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${settings.openaiApiKey}`,
          "Content-Type": "application/json",
          "OpenAI-Beta": "assistants=v2"
        },
        body: JSON.stringify({
          role: "user",
          content: `Desenvolva um prompt de sistema completo e detalhado a partir deste conceito básico: "${prompt}"`
        })
      });

      if (!messageRes.ok) {
        const error = await messageRes.json();
        throw new Error(error.error?.message || 'Erro ao enviar mensagem');
      }

      const runRes = await fetch(`https://api.openai.com/v1/threads/${thread.id}/runs`, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${settings.openaiApiKey}`,
          "Content-Type": "application/json",
          "OpenAI-Beta": "assistants=v2"
        },
        body: JSON.stringify({
          assistant_id: settings.promptMakerAssistantId
        })
      });

      if (!runRes.ok) {
        const error = await runRes.json();
        throw new Error(error.error?.message || 'Erro ao iniciar execução');
      }

      const run = await runRes.json();

      let runStatus = run.status;

      while (runStatus !== 'completed' && runStatus !== 'failed' && runStatus !== 'cancelled') {
        await new Promise(resolve => setTimeout(resolve, 1000));

        const statusRes = await fetch(`https://api.openai.com/v1/threads/${thread.id}/runs/${run.id}`, {
          headers: {
            "Authorization": `Bearer ${settings.openaiApiKey}`,
            "OpenAI-Beta": "assistants=v2"
          }
        });

        if (!statusRes.ok) {
          const error = await statusRes.json();
          throw new Error(error.error?.message || 'Erro ao verificar status');
        }

        const statusData = await statusRes.json();
        runStatus = statusData.status;
      }

      if (runStatus !== 'completed') {
        throw new Error(`Execução falhou com status: ${runStatus}`);
      }

      const messagesRes = await fetch(`https://api.openai.com/v1/threads/${thread.id}/messages`, {
        headers: {
          "Authorization": `Bearer ${settings.openaiApiKey}`,
          "OpenAI-Beta": "assistants=v2"
        }
      });

      if (!messagesRes.ok) {
        const error = await messagesRes.json();
        throw new Error(error.error?.message || 'Erro ao obter mensagens');
      }

      const messagesData = await messagesRes.json();

      const assistantMessages = messagesData.data.filter(msg => msg.role === 'assistant');

      if (assistantMessages.length > 0) {
        const latestMessage = assistantMessages[0];
        const generatedPrompt = latestMessage.content[0].text.value;
        setResult(generatedPrompt);

        toast({
          title: "Prompt gerado",
          description: "O prompt foi desenvolvido com sucesso.",
        });
      } else {
        throw new Error('Nenhuma resposta do assistente encontrada');
      }
    } catch (error) {
      console.error("Erro ao gerar prompt:", error);

      toast({
        title: "Erro ao gerar prompt",
        description: error instanceof Error ? error.message : "Erro desconhecido",
        variant: "destructive",
      });

      setResult('');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopyToClipboard = (text) => {
    navigator.clipboard.writeText(text);

    toast({
      title: "Copiado!",
      description: "O prompt foi copiado para a área de transferência.",
    });
  };

  const handleSavePrompt = () => {
    if (!savedPrompt.title.trim() || !savedPrompt.category.trim()) {
      toast({
        title: "Campos obrigatórios",
        description: "Título e categoria são obrigatórios.",
        variant: "destructive",
      });
      return;
    }

    try {
      addPrompt(savedPrompt.title, result, savedPrompt.category);

      setIsSaveDialogOpen(false);
      setSavedPrompt({
        title: '',
        category: '',
      });

      toast({
        title: "Prompt salvo",
        description: "Seu prompt foi salvo na biblioteca com sucesso.",
      });
    } catch (error) {
      console.error("Erro ao salvar prompt:", error);

      toast({
        title: "Erro ao salvar",
        description: "Ocorreu um erro ao tentar salvar seu prompt. Tente novamente.",
        variant: "destructive",
      });
    }
  };

  const handleTemplateChange = (template: typeof templates[0]) => {
    setSelectedTemplate(template);
    setPrompt(template.content);
    setResult('');
  };

  return (
    <div className="p-6 animate-fadeIn">
      <h1 className="text-2xl font-tech-mono text-terminal mb-4">PROMPT MAKER<span className="text-terminal/70">_</span></h1>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Sidebar com Templates */}
        <div className="lg:col-span-3">
          <Card className="bg-black border-terminal/30">
            <CardContent className="p-4">
              <h2 className="text-md font-semibold text-terminal mb-3 flex items-center">
                <LayoutTemplate size={16} className="mr-2 text-terminal/70" />
                Templates
              </h2>

              <div className="space-y-1.5">
                {templates.map((template) => (
                  <Button
                    key={template.id}
                    variant="outline"
                    className={`w-full justify-start text-left ${
                      selectedTemplate.id === template.id
                        ? 'bg-terminal/10 text-terminal border-terminal'
                        : 'bg-black border-terminal/30 text-terminal/80 hover:bg-terminal/5 hover:text-terminal'
                    }`}
                    onClick={() => handleTemplateChange(template)}
                  >
                    <span className="mr-2">{template.icon}</span>
                    {template.title}
                  </Button>
                ))}
              </div>

              {!settings.openaiApiKey && (
                <div className="mt-4 p-3 bg-terminal/5 border border-terminal/30 rounded-sm">
                  <div className="flex items-center text-terminal/80 text-sm mb-2">
                    <Settings size={14} className="mr-1.5 flex-shrink-0" />
                    <span>Chave API OpenAI não configurada</span>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full bg-terminal/10 border-terminal/30 text-terminal hover:bg-terminal/20"
                    onClick={() => window.location.href = '/settings'}
                  >
                    Configurar Chave
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Área Principal */}
        <div className="lg:col-span-9 space-y-6">
          <Card className="bg-black border-terminal/30">
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <h3 className="text-md font-semibold text-terminal flex items-center">
                    <MessageSquare size={16} className="mr-2" />
                    Seu Prompt Básico
                  </h3>
                  <p className="text-sm text-terminal/70">
                    Digite um conceito básico e o assistente irá desenvolver um prompt de sistema completo para você.
                    Exemplo: "Vendedor de carros", "Especialista em SEO", "Consultor de marketing".
                  </p>
                  <Textarea
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="Digite seu conceito básico aqui..."
                    className="bg-black border-terminal/30 text-terminal focus:border-terminal h-24"
                  />
                </div>

                <div className="flex justify-end">
                  <Button
                    onClick={generatePrompt}
                    className="bg-terminal/10 border border-terminal hover:bg-terminal/20 text-terminal"
                    disabled={isGenerating || !prompt.trim() || !settings.openaiApiKey || !settings.promptMakerAssistantId}
                  >
                    {isGenerating ? (
                      <>
                        <RefreshCw size={16} className="mr-2 animate-spin" />
                        Gerando...
                      </>
                    ) : (
                      <>
                        <Wand2 size={16} className="mr-2" />
                        Desenvolver Prompt
                      </>
                    )}
                  </Button>
                </div>

                {result && (
                  <div className="mt-6 space-y-2">
                    <div className="flex items-center justify-between">
                      <h3 className="text-md font-semibold text-terminal flex items-center">
                        <Sparkles size={16} className="mr-2 text-terminal/80" />
                        Prompt Desenvolvido
                      </h3>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-8 bg-black border-terminal/30 text-terminal/80 hover:border-terminal hover:text-terminal"
                          onClick={() => handleCopyToClipboard(result)}
                        >
                          <Copy size={14} className="mr-1.5" />
                          Copiar
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-8 bg-black border-terminal/30 text-terminal/80 hover:border-terminal hover:text-terminal"
                          onClick={() => setIsSaveDialogOpen(true)}
                        >
                          <Save size={14} className="mr-1.5" />
                          Salvar
                        </Button>
                      </div>
                    </div>
                    <div className="p-4 bg-terminal/5 border border-terminal/30 rounded-sm min-h-[250px] max-h-[500px] overflow-y-auto">
                      <pre className="text-terminal/90 font-mono whitespace-pre-wrap text-sm">{result}</pre>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Save Dialog */}
      <Dialog open={isSaveDialogOpen} onOpenChange={setIsSaveDialogOpen}>
        <DialogContent className="bg-black border-terminal/50 sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-terminal">Salvar Prompt</DialogTitle>
            <DialogDescription className="text-terminal/70">
              Salve este prompt na sua biblioteca para uso futuro.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-terminal">Título</label>
              <Input
                placeholder="Título do prompt"
                value={savedPrompt.title}
                onChange={(e) => setSavedPrompt({ ...savedPrompt, title: e.target.value })}
                className="bg-black border-terminal/30 text-terminal"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-terminal">Categoria</label>
              <Input
                placeholder="Ex: Marketing, SEO, Escrita"
                value={savedPrompt.category}
                onChange={(e) => setSavedPrompt({ ...savedPrompt, category: e.target.value })}
                className="bg-black border-terminal/30 text-terminal"
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              onClick={() => setIsSaveDialogOpen(false)}
              variant="outline"
              className="bg-black text-terminal border-terminal/50 hover:bg-terminal/10"
            >
              Cancelar
            </Button>
            <Button
              onClick={handleSavePrompt}
              className="bg-terminal/10 border border-terminal hover:bg-terminal/20 text-terminal"
            >
              <Save size={16} className="mr-2" />
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

import { FileText, Zap, BookText, LayoutTemplate, Settings } from 'lucide-react';