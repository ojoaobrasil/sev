
import React, { useState, useEffect } from 'react';
import { useSettingsStore } from '@/store/dataStore';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Bot, 
  Send, 
  RefreshCw, 
  Save,
  Settings, 
  Copy, 
  CheckCheck,
  User
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { AppLayout } from '@/components/layout/AppLayout';

const Assistants = () => {
  const { settings } = useSettingsStore();
  const { toast } = useToast();
  const [messages, setMessages] = useState<Array<{ role: 'user' | 'assistant' | 'system', content: string }>>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  // Configurações do assistente
  const [assistantConfig, setAssistantConfig] = useState({
    model: 'gpt-4o-mini',
    instructions: 'Você é um assistente útil e amigável.',
    temperature: 0.7,
    maxTokens: 2048,
  });

  const models = [
    { id: 'gpt-4o-mini', name: 'GPT-4o Mini' },
    { id: 'gpt-4o', name: 'GPT-4o' },
    { id: 'gpt-3.5-turbo', name: 'GPT-3.5 Turbo' },
  ];

  // Carregar configurações salvas
  useEffect(() => {
    const savedConfig = localStorage.getItem('assistant-config');
    if (savedConfig) {
      setAssistantConfig(JSON.parse(savedConfig));
    }
  }, []);

  const handleSaveConfig = () => {
    localStorage.setItem('assistant-config', JSON.stringify(assistantConfig));
    toast({
      title: "Configurações salvas",
      description: "As configurações do assistente foram salvas com sucesso.",
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!inputMessage.trim()) return;

    if (!settings.openaiApiKey) {
      toast({
        title: "API Key não encontrada",
        description: "Configure sua chave da OpenAI nas configurações",
        variant: "destructive"
      });
      return;
    }

    const userMessage = { role: 'user' as const, content: inputMessage };
    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsLoading(true);

    try {
      // Preparar a chamada para a API OpenAI
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${settings.openaiApiKey}`
        },
        body: JSON.stringify({
          model: assistantConfig.model,
          messages: [
            {
              role: 'system',
              content: assistantConfig.instructions
            },
            ...messages,
            userMessage
          ],
          temperature: assistantConfig.temperature,
          max_tokens: assistantConfig.maxTokens,
        })
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error?.message || 'Erro ao chamar a API da OpenAI');
      }

      const data = await response.json();
      const assistantMessage = { 
        role: 'assistant' as const, 
        content: data.choices[0].message.content 
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Erro:', error);
      toast({
        title: "Erro na requisição",
        description: error instanceof Error ? error.message : "Ocorreu um erro desconhecido",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast({
      title: "Copiado!",
      description: "Texto copiado para a área de transferência",
    });
  };

  const clearChat = () => {
    setMessages([]);
    toast({
      title: "Chat limpo",
      description: "O histórico do chat foi apagado",
    });
  };

  return (
    <div className="p-4 md:p-6 animate-fadeIn">
      <h1 className="text-2xl font-tech-mono text-terminal mb-6">ASSISTENTES<span className="text-terminal/70">_</span></h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Painel de Configuração */}
        <div className="lg:col-span-1">
          <Card className="bg-black border-terminal/30">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Bot size={20} className="text-terminal" />
                  Configuração do Assistente
                </div>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={handleSaveConfig}
                  title="Salvar configurações"
                  className="border-terminal/30 hover:border-terminal text-terminal/70 hover:text-terminal"
                >
                  <Save size={16} />
                </Button>
              </CardTitle>
              <CardDescription className="text-terminal/70">
                Configure as opções do assistente para testar diferentes comportamentos
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1 text-terminal/80">Modelo</label>
                <Select 
                  value={assistantConfig.model}
                  onValueChange={(value) => setAssistantConfig({...assistantConfig, model: value})}
                >
                  <SelectTrigger className="bg-black border-terminal/30 text-terminal">
                    <SelectValue placeholder="Selecione um modelo" />
                  </SelectTrigger>
                  <SelectContent className="bg-black border-terminal/30 text-terminal">
                    {models.map(model => (
                      <SelectItem key={model.id} value={model.id} className="hover:bg-terminal/10">
                        {model.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1 text-terminal/80">
                  Instruções do Sistema
                </label>
                <Textarea
                  value={assistantConfig.instructions}
                  onChange={(e) => setAssistantConfig({...assistantConfig, instructions: e.target.value})}
                  rows={4}
                  placeholder="Instruções para o assistente..."
                  className="w-full bg-black border-terminal/30 text-terminal resize-none"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1 text-terminal/80">
                  Temperatura: {assistantConfig.temperature}
                </label>
                <input
                  type="range"
                  min="0"
                  max="2"
                  step="0.1"
                  value={assistantConfig.temperature}
                  onChange={(e) => setAssistantConfig({...assistantConfig, temperature: parseFloat(e.target.value)})}
                  className="w-full accent-terminal"
                />
                <div className="flex justify-between text-xs mt-1 text-terminal/60">
                  <span>Mais preciso</span>
                  <span>Mais criativo</span>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1 text-terminal/80">
                  Máximo de Tokens: {assistantConfig.maxTokens}
                </label>
                <input
                  type="range"
                  min="256"
                  max="4096"
                  step="256"
                  value={assistantConfig.maxTokens}
                  onChange={(e) => setAssistantConfig({...assistantConfig, maxTokens: parseInt(e.target.value)})}
                  className="w-full accent-terminal"
                />
                <div className="flex justify-between text-xs mt-1 text-terminal/60">
                  <span>Respostas curtas</span>
                  <span>Respostas longas</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Chat para Testar */}
        <div className="lg:col-span-2">
          <Card className="bg-black border-terminal/30 h-full flex flex-col">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Bot size={20} className="text-terminal" />
                  Testar Assistente
                </div>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={clearChat}
                  className="border-terminal/30 hover:border-terminal text-terminal/70 hover:text-terminal"
                >
                  Limpar Chat
                </Button>
              </CardTitle>
              <CardDescription className="text-terminal/70">
                Teste seu assistente com as configurações definidas
              </CardDescription>
            </CardHeader>

            <CardContent className="flex-grow overflow-hidden flex flex-col">
              <ScrollArea className="flex-grow h-[400px] pr-4">
                {messages.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full text-center p-4">
                    <Bot size={40} className="text-terminal/20 mb-4" />
                    <p className="text-terminal/50">
                      Envie uma mensagem para começar a conversa com o assistente
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {messages.map((message, index) => (
                      <div key={index} className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`
                          max-w-[80%] p-3 rounded-lg
                          ${message.role === 'user' 
                            ? 'bg-terminal/20 border border-terminal/30 ml-10' 
                            : 'bg-terminal/10 border border-terminal/20 mr-10'}
                        `}>
                          <div className="flex items-center gap-2 mb-1">
                            {message.role === 'user' ? (
                              <>
                                <span className="text-sm font-medium text-terminal">Você</span>
                                <User size={14} className="text-terminal/70" />
                              </>
                            ) : (
                              <>
                                <Bot size={14} className="text-terminal/70" />
                                <span className="text-sm font-medium text-terminal">Assistente</span>
                              </>
                            )}
                          </div>
                          <p className="text-sm text-terminal/90 whitespace-pre-wrap">{message.content}</p>

                          {message.role === 'assistant' && (
                            <div className="flex justify-end mt-2">
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                onClick={() => copyToClipboard(message.content)}
                                className="h-7 px-2 text-terminal/50 hover:text-terminal hover:bg-terminal/10"
                              >
                                {copied ? <CheckCheck size={14} /> : <Copy size={14} />}
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}

                    {isLoading && (
                      <div className="flex justify-start">
                        <div className="bg-terminal/10 border border-terminal/20 p-3 rounded-lg max-w-[80%] mr-10">
                          <div className="flex items-center gap-2">
                            <Bot size={14} className="text-terminal/70" />
                            <span className="text-sm font-medium text-terminal">Assistente</span>
                          </div>
                          <div className="flex items-center gap-2 mt-2">
                            <RefreshCw size={14} className="text-terminal/60 animate-spin" />
                            <span className="text-sm text-terminal/60">Gerando resposta...</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </ScrollArea>
            </CardContent>

            <CardFooter className="pt-4 border-t border-terminal/20">
              <form onSubmit={handleSubmit} className="w-full flex gap-2">
                <Input
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  placeholder="Digite sua mensagem aqui..."
                  className="flex-grow bg-black border-terminal/30 text-terminal"
                  disabled={isLoading}
                />
                <Button 
                  type="submit"
                  disabled={isLoading || !inputMessage.trim()}
                  className="bg-terminal/10 border border-terminal hover:bg-terminal/20 text-terminal"
                >
                  {isLoading ? (
                    <RefreshCw size={18} className="animate-spin" />
                  ) : (
                    <Send size={18} />
                  )}
                </Button>
              </form>
            </CardFooter>
          </Card>
        </div>
      </div>

      <p className="text-xs text-terminal/40 mt-4">
        <Settings size={12} className="inline mr-1" />
        Configure sua chave da API OpenAI nas configurações para utilizar este recurso.
      </p>
    </div>
  );
};

export default Assistants;
