import React, { useState, useEffect } from 'react';
import { useSettingsStore } from '@/store/dataStore';
import { useTheme } from '@/hooks/use-theme';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { 
  Settings as SettingsIcon, 
  Save, 
  Key, 
  Globe, 
  Eye, 
  EyeOff,
  Sun,
  Moon,
  Check,
  RefreshCw,
  PanelLeftClose,
  PanelLeft
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { useToast } from '@/hooks/use-toast';

export default function Settings() {
  const { settings, updateSettings } = useSettingsStore();
  const { theme, toggleTheme } = useTheme();
  const [formState, setFormState] = useState({
    openaiApiKey: settings.openaiApiKey || '',
    language: 'pt-BR',
    theme: settings.theme,
    enableNotifications: false,
    autoSave: true,
    sidebarOpen: settings.sidebarOpen
  });
  const [showOpenAIKey, setShowOpenAIKey] = useState(false);
  const [showPromptMakerKey, setShowPromptMakerKey] = useState(false);
  const [showChatBubbleKey, setShowChatBubbleKey] = useState(false);
  const [isResetting, setIsResetting] = useState(false);
  const { toast } = useToast();
  
  // Atualizar estado quando o tema mudar
  useEffect(() => {
    setFormState(prev => ({
      ...prev,
      theme: settings.theme
    }));
  }, [settings.theme]);

  const handleChange = (field: string, value: any) => {
    setFormState({
      ...formState,
      [field]: value,
    });
    
    // Aplicar mudanças de tema imediatamente
    if (field === 'theme' && value !== settings.theme) {
      updateSettings({ theme: value as 'dark' | 'light' });
    }
    
    // Aplicar mudanças de sidebar imediatamente
    if (field === 'sidebarOpen' && value !== settings.sidebarOpen) {
      updateSettings({ sidebarOpen: value });
    }
  };

  const handleSave = () => {
    // Extrair apenas as propriedades válidas do Settings
    const { openaiApiKey, theme, sidebarOpen } = formState;
    updateSettings({ 
      openaiApiKey, 
      theme: theme as 'dark' | 'light', 
      sidebarOpen 
    });
    
    toast({
      title: "Configurações salvas",
      description: "Suas configurações foram atualizadas com sucesso.",
    });
  };

  const handleReset = () => {
    setIsResetting(true);
    
    setTimeout(() => {
      const defaultSettings = {
        openaiApiKey: '',
        language: 'pt-BR',
        theme: 'dark' as 'dark',
        enableNotifications: false,
        autoSave: true,
        sidebarOpen: false
      };
      
      setFormState(defaultSettings);
      updateSettings({ 
        openaiApiKey: '', 
        theme: 'dark', 
        sidebarOpen: false 
      });
      
      setIsResetting(false);
      
      toast({
        title: "Configurações redefinidas",
        description: "Suas configurações foram redefinidas para os valores padrão.",
      });
    }, 1000);
  };

  return (
    <div className="p-6 animate-fadeIn">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
        <h1 className="text-2xl font-tech-mono text-terminal mb-4 md:mb-0">CONFIGURAÇÕES<span className="text-terminal/70">_</span></h1>
        
        <div className="flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2 w-full md:w-auto">
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" className="bg-black border-terminal/30 text-terminal hover:border-terminal">
                <RefreshCw size={16} className="mr-2" />
                Redefinir
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-black border-terminal/50 sm:max-w-md">
              <DialogHeader>
                <DialogTitle className="text-terminal">Redefinir configurações</DialogTitle>
                <DialogDescription className="text-terminal/70">
                  Tem certeza que deseja redefinir todas as configurações para os valores padrão?
                </DialogDescription>
              </DialogHeader>
              <DialogFooter>
                <Button 
                  variant="outline" 
                  onClick={() => {}} 
                  className="bg-black text-terminal border-terminal/50 hover:bg-terminal/10"
                >
                  Cancelar
                </Button>
                <Button 
                  onClick={handleReset} 
                  className="bg-red-900/30 hover:bg-red-900/50 text-red-400 border border-red-500/50"
                  disabled={isResetting}
                >
                  {isResetting ? (
                    <>
                      <RefreshCw size={16} className="mr-2 animate-spin" />
                      Redefinindo...
                    </>
                  ) : (
                    <>
                      <RefreshCw size={16} className="mr-2" />
                      Redefinir
                    </>
                  )}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          
          <Button 
            onClick={handleSave} 
            className="bg-terminal/10 border border-terminal hover:bg-terminal/20 text-terminal"
          >
            <Save size={16} className="mr-2" />
            Salvar Configurações
          </Button>
        </div>
      </div>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList className="bg-black border-terminal/30 p-0">
          <TabsTrigger 
            value="general" 
            className="data-[state=active]:bg-terminal/10 data-[state=active]:text-terminal data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-terminal rounded-none px-4 py-2"
          >
            Geral
          </TabsTrigger>
          <TabsTrigger 
            value="api" 
            className="data-[state=active]:bg-terminal/10 data-[state=active]:text-terminal data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-terminal rounded-none px-4 py-2"
          >
            API
          </TabsTrigger>
          <TabsTrigger 
            value="appearance" 
            className="data-[state=active]:bg-terminal/10 data-[state=active]:text-terminal data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-terminal rounded-none px-4 py-2"
          >
            Aparência
          </TabsTrigger>
          <TabsTrigger 
            value="notifications" 
            className="data-[state=active]:bg-terminal/10 data-[state=active]:text-terminal data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-terminal rounded-none px-4 py-2"
          >
            Notificações
          </TabsTrigger>
        </TabsList>
        
        {/* General Tab */}
        <TabsContent value="general" className="space-y-4">
          <Card className="bg-black border-terminal/30">
            <CardHeader>
              <CardTitle className="text-terminal flex items-center">
                <Globe size={18} className="mr-2 text-terminal/70" />
                Configurações Gerais
              </CardTitle>
              <CardDescription className="text-terminal/70">
                Configure o idioma e outras opções gerais do sistema.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label className="text-terminal">Idioma</Label>
                <select 
                  value={formState.language} 
                  onChange={(e) => handleChange('language', e.target.value)}
                  className="w-full p-2 rounded-md bg-black border border-terminal/30 text-terminal"
                >
                  <option value="pt-BR">Português (Brasil)</option>
                  <option value="en-US">English (United States)</option>
                  <option value="es-ES">Español</option>
                </select>
                <p className="text-xs text-terminal/50">
                  Selecione o idioma em que deseja usar o sistema.
                </p>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="auto_save" className="text-terminal">Auto-salvar</Label>
                  <Switch 
                    id="auto_save" 
                    checked={formState.autoSave} 
                    onCheckedChange={(checked) => handleChange('autoSave', checked)}
                    className="data-[state=checked]:bg-terminal data-[state=checked]:text-black"
                  />
                </div>
                <p className="text-xs text-terminal/50">
                  Salva automaticamente suas alterações em anotações, ideias e tarefas.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* API Tab */}
        <TabsContent value="api" className="space-y-4">
          <Card className="bg-black border-terminal/30">
            <CardHeader>
              <CardTitle className="text-terminal flex items-center">
                <Key size={18} className="mr-2 text-terminal/70" />
                Chaves de API
              </CardTitle>
              <CardDescription className="text-terminal/70">
                Configure suas chaves de API para usar serviços externos.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                {/* OpenAI API Key Principal */}
                <div className="space-y-2">
                  <Label htmlFor="openai_key" className="text-terminal">OpenAI API Key Principal</Label>
                  <div className="relative">
                    <Input
                      id="openai_key"
                      type={showOpenAIKey ? "text" : "password"}
                      placeholder="sk-..."
                      value={formState.openaiApiKey}
                      onChange={(e) => handleChange('openaiApiKey', e.target.value)}
                      className="pr-10 bg-black border-terminal/30 text-terminal"
                    />
                    <button
                      type="button"
                      onClick={() => setShowOpenAIKey(!showOpenAIKey)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-terminal/60 hover:text-terminal"
                    >
                      {showOpenAIKey ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                  <p className="text-xs text-terminal/50">
                    API Key principal que será usada em todas as ferramentas de IA.
                  </p>
                </div>

                {/* ID do Assistente do Prompt Maker */}
                <div className="space-y-2">
                  <Label htmlFor="prompt_maker_assistant_id" className="text-terminal">ID do Assistente - Prompt Maker</Label>
                  <div className="relative">
                    <Input
                      id="prompt_maker_assistant_id"
                      type={showPromptMakerKey ? "text" : "password"}
                      placeholder="asst_..."
                      value={formState.promptMakerAssistantId}
                      onChange={(e) => handleChange('promptMakerAssistantId', e.target.value)}
                      className="pr-10 bg-black border-terminal/30 text-terminal"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPromptMakerKey(!showPromptMakerKey)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-terminal/60 hover:text-terminal"
                    >
                      {showPromptMakerKey ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                  <p className="text-xs text-terminal/50">
                    ID do assistente específico para o Prompt Maker.
                  </p>
                </div>

                {/* ID do Assistente do Chat Flutuante */}
                <div className="space-y-2">
                  <Label htmlFor="chat_bubble_assistant_id" className="text-terminal">ID do Assistente - Chat Flutuante</Label>
                  <div className="relative">
                    <Input
                      id="chat_bubble_assistant_id"
                      type={showChatBubbleKey ? "text" : "password"}
                      placeholder="asst_..."
                      value={formState.chatBubbleAssistantId}
                      onChange={(e) => handleChange('chatBubbleAssistantId', e.target.value)}
                      className="pr-10 bg-black border-terminal/30 text-terminal"
                    />
                    <button
                      type="button"
                      onClick={() => setShowChatBubbleKey(!showChatBubbleKey)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-terminal/60 hover:text-terminal"
                    >
                      {showChatBubbleKey ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                  <p className="text-xs text-terminal/50">
                    ID do assistente específico para o Chat Flutuante.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Appearance Tab */}
        <TabsContent value="appearance" className="space-y-4">
          <Card className="bg-black border-terminal/30">
            <CardHeader>
              <CardTitle className="text-terminal flex items-center">
                {formState.theme === 'dark' ? (
                  <Moon size={18} className="mr-2 text-terminal/70" />
                ) : (
                  <Sun size={18} className="mr-2 text-terminal/70" />
                )}
                Aparência
              </CardTitle>
              <CardDescription className="text-terminal/70">
                Personalize a aparência do sistema.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label className="text-terminal">Tema</Label>
                <div className="grid grid-cols-2 gap-4">
                  <div 
                    className={`p-4 rounded-md border cursor-pointer transition-all ${
                      formState.theme === 'dark' 
                        ? 'border-terminal bg-terminal/10' 
                        : 'border-terminal/30 bg-black hover:border-terminal/60'
                    }`}
                    onClick={() => handleChange('theme', 'dark')}
                  >
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-terminal font-medium">Modo Escuro</span>
                      {formState.theme === 'dark' && (
                        <Check size={16} className="text-terminal" />
                      )}
                    </div>
                    <div className="h-20 bg-black border border-terminal/30"></div>
                  </div>
                  
                  <div 
                    className={`p-4 rounded-md border cursor-pointer transition-all ${
                      formState.theme === 'light' 
                        ? 'border-terminal bg-terminal/10' 
                        : 'border-terminal/30 bg-black hover:border-terminal/60'
                    }`}
                    onClick={() => handleChange('theme', 'light')}
                  >
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-terminal font-medium">Modo Claro</span>
                      {formState.theme === 'light' && (
                        <Check size={16} className="text-terminal" />
                      )}
                    </div>
                    <div className="h-20 bg-zinc-100 border border-terminal/30"></div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Notifications Tab */}
        <TabsContent value="notifications" className="space-y-4">
          <Card className="bg-black border-terminal/30">
            <CardHeader>
              <CardTitle className="text-terminal flex items-center">
                <SettingsIcon size={18} className="mr-2 text-terminal/70" />
                Notificações
              </CardTitle>
              <CardDescription className="text-terminal/70">
                Configure suas preferências de notificação.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="enable_notifications" className="text-terminal">Ativar Notificações</Label>
                  <Switch 
                    id="enable_notifications" 
                    checked={formState.enableNotifications} 
                    onCheckedChange={(checked) => handleChange('enableNotifications', checked)}
                    className="data-[state=checked]:bg-terminal data-[state=checked]:text-black"
                  />
                </div>
                <p className="text-xs text-terminal/50">
                  Receba notificações sobre tarefas, atualizações e lembretes.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}