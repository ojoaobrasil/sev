import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { Idea, UsefulLink, Task, Note, Prompt } from '../types'

// Structures for the different data types
interface Settings {
  openaiApiKey: string | null;
  assistantId: string | null;
  theme: 'dark' | 'light';
  sidebarOpen: boolean;
  webhookUrl: string | null;
  promptMakerAssistantId: string | null;
  chatBubbleAssistantId: string | null;
}

// Atualizar os valores padrão
const defaultSettings: Settings = {
  openaiApiKey: null,
  assistantId: null,
  theme: 'dark',
  sidebarOpen: false,
  webhookUrl: 'https://gen.simplebot.online/webhook/b8f10f59-0108-43f1-afce-e782eda6ebe0',
  promptMakerAssistantId: null,
  chatBubbleAssistantId: null,
};

interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'success' | 'error';
  read: boolean;
  createdAt: Date;
}

interface NotificationsStore {
  notifications: Notification[];
  addNotification: (title: string, message: string, type: Notification['type']) => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  deleteNotification: (id: string) => void;
  clearAllNotifications: () => void;
}

interface SettingsStore {
  settings: Settings;
  updateSettings: (newSettings: Partial<Settings>) => void;
}

interface IdeasStore {
  ideas: Idea[];
  addIdea: (title: string, description: string, category: string) => void;
  updateIdea: (id: string, data: Partial<Idea>) => void;
  deleteIdea: (id: string) => void;
}

interface LinksStore {
  links: UsefulLink[];
  addLink: (title: string, url: string, description: string, category: string) => void;
  updateLink: (id: string, data: Partial<UsefulLink>) => void;
  deleteLink: (id: string) => void;
}

interface TasksStore {
  tasks: Task[];
  addTask: (title: string, description: string, dueDate: Date) => void;
  updateTask: (id: string, data: Partial<Task>) => void;
  updateTaskStatus: (id: string, status: Task['status']) => void;
  deleteTask: (id: string) => void;
}

interface NotesStore {
  notes: Note[];
  addNote: (title: string, content: string) => void;
  updateNote: (id: string, data: Partial<Note>) => void;
  deleteNote: (id: string) => void;
}

interface PromptsStore {
  prompts: Prompt[];
  addPrompt: (title: string, content: string, category: string) => void;
  updatePrompt: (id: string, data: Partial<Prompt>) => void;
  deletePrompt: (id: string) => void;
}

// Create the settings store
export const useSettingsStore = create<SettingsStore>()(
  persist(
    (set) => ({
      settings: {
        openaiApiKey: null,
        assistantId: null,
        theme: 'dark',
        sidebarOpen: false,
        webhookUrl: 'https://gen.simplebot.online/webhook/b8f10f59-0108-43f1-afce-e782eda6ebe0',
        promptMakerAssistantId: null,
        chatBubbleAssistantId: null,
      },
      updateSettings: (newSettings) => set((state) => ({
        settings: { ...state.settings, ...newSettings },
      })),
    }),
    {
      name: 'settings-storage',
    }
  )
);

// Create the ideas store
export const useIdeasStore = create<IdeasStore>()(
  persist(
    (set) => ({
      ideas: [],
      addIdea: (title, description, category) => set((state) => ({
        ideas: [
          ...state.ideas,
          {
            id: crypto.randomUUID(),
            title,
            description,
            category,
            createdAt: new Date(),
          },
        ],
      })),
      updateIdea: (id, data) => set((state) => ({
        ideas: state.ideas.map((idea) =>
          idea.id === id ? { ...idea, ...data } : idea
        ),
      })),
      deleteIdea: (id) => set((state) => ({
        ideas: state.ideas.filter((idea) => idea.id !== id),
      })),
    }),
    {
      name: 'ideas-storage',
    }
  )
);

// Create the links store
export const useLinksStore = create<LinksStore>()(
  persist(
    (set) => ({
      links: [],
      addLink: (title, url, description, category) => set((state) => ({
        links: [
          ...state.links,
          {
            id: crypto.randomUUID(),
            title,
            url,
            description,
            category,
          },
        ],
      })),
      updateLink: (id, data) => set((state) => ({
        links: state.links.map((link) =>
          link.id === id ? { ...link, ...data } : link
        ),
      })),
      deleteLink: (id) => set((state) => ({
        links: state.links.filter((link) => link.id !== id),
      })),
    }),
    {
      name: 'links-storage',
    }
  )
);

// Create the tasks store
export const useTasksStore = create<TasksStore>()(
  persist(
    (set) => ({
      tasks: [],
      addTask: (title, description, dueDate) => set((state) => ({
        tasks: [
          ...state.tasks,
          {
            id: crypto.randomUUID(),
            title,
            description,
            dueDate,
            status: 'pending' as const,
            createdAt: new Date(),
          },
        ],
      })),
      updateTask: (id, data) => set((state) => ({
        tasks: state.tasks.map((task) =>
          task.id === id ? { ...task, ...data } : task
        ),
      })),
      updateTaskStatus: (id, status) => set((state) => ({
        tasks: state.tasks.map((task) =>
          task.id === id ? { ...task, status } : task
        ),
      })),
      deleteTask: (id) => set((state) => ({
        tasks: state.tasks.filter((task) => task.id !== id),
      })),
    }),
    {
      name: 'tasks-storage',
    }
  )
);

// Create the notes store
export const useNotesStore = create<NotesStore>()(
  persist(
    (set) => ({
      notes: [],
      addNote: (title, content) => set((state) => ({
        notes: [
          ...state.notes,
          {
            id: crypto.randomUUID(),
            title,
            content,
            createdAt: new Date(),
            updatedAt: new Date(),
          },
        ],
      })),
      updateNote: (id, data) => set((state) => ({
        notes: state.notes.map((note) =>
          note.id === id
            ? { ...note, ...data, updatedAt: new Date() }
            : note
        ),
      })),
      deleteNote: (id) => set((state) => ({
        notes: state.notes.filter((note) => note.id !== id),
      })),
    }),
    {
      name: 'notes-storage',
    }
  )
);

// Create the prompts store
export const usePromptsStore = create<PromptsStore>()(
  persist(
    (set) => ({
      prompts: [],
      addPrompt: (title, content, category) => set((state) => ({
        prompts: [
          ...state.prompts,
          {
            id: crypto.randomUUID(),
            title,
            content,
            category,
            createdAt: new Date(),
          },
        ],
      })),
      updatePrompt: (id, data) => set((state) => ({
        prompts: state.prompts.map((prompt) =>
          prompt.id === id ? { ...prompt, ...data } : prompt
        ),
      })),
      deletePrompt: (id) => set((state) => ({
        prompts: state.prompts.filter((prompt) => prompt.id !== id),
      })),
    }),
    {
      name: 'prompts-storage',
    }
  )
);

// Create the notifications store
export const useNotificationsStore = create<NotificationsStore>()(
  persist(
    (set) => ({
      notifications: [],
      addNotification: (title, message, type) => set((state) => ({
        notifications: [
          {
            id: crypto.randomUUID(),
            title,
            message,
            type,
            read: false,
            createdAt: new Date(),
          },
          ...state.notifications,
        ],
      })),
      markAsRead: (id) => set((state) => ({
        notifications: state.notifications.map((notif) =>
          notif.id === id ? { ...notif, read: true } : notif
        ),
      })),
      markAllAsRead: () => set((state) => ({
        notifications: state.notifications.map((notif) => ({ ...notif, read: true })),
      })),
      deleteNotification: (id) => set((state) => ({
        notifications: state.notifications.filter((notif) => notif.id !== id),
      })),
      clearAllNotifications: () => set({ notifications: [] }),
    }),
    {
      name: 'notifications-storage',
    }
  )
);